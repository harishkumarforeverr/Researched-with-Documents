1. https://www.codica.com/blog/how-to-create-pwa-with-react/
2. https://scandiweb.com/blog/learn-all-about-progressive-web-apps/#pwa-examples-for-inspiration
